# Tokens

Every token with its value and when to use it. Values written as `{name}` point to another token. Per-theme values are shown as `sunlit / workshop`.

## Colour

| Token | Value | Usage |
| --- | --- | --- |
| `pal-maroon` | `#9d0910` | Card maroon, shared by both looks (the first draft called it red). Fill for primary buttons and price blocks, and the offset shadow of cream paper cards in Bolt & Tag. Text on it is on-accent (7.5:1). As text it reads on cream (7.5:1), not on navy (1.6:1). |
| `pal-cream` | `#fdf0d5` | Card cream. Page ground of Sunlit Atelier, and the paper card colour and ink of Bolt & Tag. |
| `pal-navy` | `#003049` | Card navy. Ink of Sunlit Atelier, page ground of Bolt & Tag, and ink on cream paper. |
| `pal-periwinkle` | `#6f69b1` | Palette 1 violet. Support fill in Sunlit Atelier. It is 4.3:1 on cream, so never small text; use pal-violet-ink for text. |
| `pal-sky` | `#84d2f6` | Palette 1 sky blue, the original supplied value. Pale tints and the focus ring in Bolt & Tag. Sunlit Atelier now uses pal-sky-deep for its field. |
| `pal-slate` | `#829399` | Palette 2 grey-teal. Hairlines, stitching and support fills in Bolt & Tag. 4.3:1 on navy, so a line or a block, never body text. |
| `pal-clay` | `#ae847e` | Palette 2 clay (the first draft called it dusty rose). Offset shadow on dark blue (4.2:1 on navy), key shadows, and clay paper tags in Bolt & Tag. Text on it is navy-deep only (5.1:1). |
| `pal-cream-light` | `#fff9ec` | Derived: the lightest cream. Raised surfaces and text on periwinkle in Sunlit Atelier. |
| `pal-cream-deep` | `#f4e2b8` | Derived: a deeper cream for the footer band and quiet fields in Sunlit Atelier. |
| `pal-cream-edge` | `#e8d6ac` | Derived: the shade of a paper card's edge, grain and stitch line, on cream and cream-light only. |
| `pal-sky-pale` | `#d6eefb` | Derived: sky tint for hover fills and photo grounds in Sunlit Atelier. |
| `pal-sky-deep` | `#5fb9e8` | Derived: sky blue taken down a step. The large flat field in Sunlit Atelier. Navy text on it is 6.3:1; maroon text is not allowed (3.9:1). |
| `pal-sun` | `#f2c35b` | Derived: warm sun gold. Decoration only, one disc per view in Sunlit Atelier. Never text, never a button. |
| `pal-violet-ink` | `#55509a` | Derived: periwinkle darkened until it reads as text (5.9:1 on cream). Links and the focus ring in Sunlit Atelier. |
| `pal-navy-deep` | `#00202f` | Derived: the deepest navy. Footer band in Bolt & Tag, and the only text colour on clay and slate blocks. |
| `pal-navy-raised` | `#0b4160` | Derived: lifted navy for cards, tags and inputs in Bolt & Tag. |
| `pal-clay-light` | `#d2aaa3` | Derived: clay lightened for accent text on navy in Bolt & Tag (6.6:1 on navy, 5.2:1 on navy-raised). |
| `pal-slate-light` | `#c3cecf` | Derived: light grey-teal for secondary text on navy in Bolt & Tag. |
| `pal-ink-mid` | `#3f5d70` | Derived: mid navy for secondary text on cream in Sunlit Atelier. |
| `ground` | sunlit: `{pal-cream}` / workshop: `{pal-navy}` | Page background. Text on it: ink, ink-soft, accent-text. |
| `ground-deep` | sunlit: `{pal-cream-deep}` / workshop: `{pal-navy-deep}` | Footer and quiet bands under ground. Text on it: ink, ink-soft, accent-text. |
| `surface` | sunlit: `{pal-cream-light}` / workshop: `{pal-navy-raised}` | Raised areas: panels and inputs. Text on it: ink, ink-soft, accent-text. In Bolt & Tag, the paper card is the hard raised piece; surface is the quieter lifted navy. |
| `ink` | sunlit: `{pal-navy}` / workshop: `{pal-cream}` | Headlines and body copy on ground, ground-deep and surface (9.6:1 or better in both themes). On highlight only in Sunlit Atelier. On paper use on-paper. |
| `ink-soft` | sunlit: `{pal-ink-mid}` / workshop: `{pal-slate-light}` | Secondary copy and captions on ground, ground-deep and surface. Not on highlight in Sunlit Atelier (4.2:1). |
| `line` | sunlit: `{pal-navy}` / workshop: `{pal-slate}` | Hairlines and form borders in Sunlit Atelier (1px). Stitching and borders on dark blue in Bolt & Tag (2px dashed or 3px solid). Meets 3:1 on ground and surface. |
| `accent` | sunlit: `{pal-maroon}` / workshop: `{pal-maroon}` | Fill for the primary button and price blocks. Label it with on-accent. Not a text colour on navy; use accent-text there. |
| `on-accent` | sunlit: `{pal-cream}` / workshop: `{pal-cream}` | Text and icons on accent (7.5:1). |
| `accent-text` | sunlit: `{pal-maroon}` / workshop: `{pal-clay-light}` | Accent coloured words and links on ground, ground-deep and surface (at least 5.2:1 in both themes). On paper use accent-on-paper. |
| `highlight` | sunlit: `{pal-sky-deep}` / workshop: `{pal-clay}` | The large colour field: deeper sky in Sunlit Atelier, clay in Bolt & Tag. Text on it: on-highlight. No focusable controls on it in Bolt & Tag (the focus ring is 2:1 there). |
| `on-highlight` | sunlit: `{pal-navy}` / workshop: `{pal-navy-deep}` | Text and drawings on highlight (6.3:1 in Sunlit Atelier, 5.1:1 in Bolt & Tag). |
| `support` | sunlit: `{pal-periwinkle}` / workshop: `{pal-slate}` | Second colour field and small accents. Text on it: on-support. |
| `on-support` | sunlit: `{pal-cream-light}` / workshop: `{pal-navy-deep}` | Text on support (4.6:1 in Sunlit Atelier, 5.3:1 in Bolt & Tag). Use at 17px or larger. |
| `focus` | sunlit: `{pal-violet-ink}` / workshop: `{pal-sky}` | Focus ring, 3px solid, 2px offset. At least 3:1 on ground, surface and highlight in Sunlit Atelier; at least 5:1 on ground, surface and accent in Bolt & Tag, and on paper use accent-on-paper. |
| `paper` | sunlit: `{pal-cream-light}` / workshop: `{pal-cream}` | The paper card: a stiff cream label like the tags on new jeans. Always paired with an offset shadow in Bolt & Tag. Text on it: on-paper, on-paper-soft, accent-on-paper. |
| `on-paper` | sunlit: `{pal-navy}` / workshop: `{pal-navy}` | Headlines and body copy on paper (9.7:1 or better). |
| `on-paper-soft` | sunlit: `{pal-ink-mid}` / workshop: `{pal-ink-mid}` | Secondary copy and captions on paper (6.2:1). |
| `accent-on-paper` | sunlit: `{pal-maroon}` / workshop: `{pal-maroon}` | Maroon words, prices and links on paper (7.5:1). |
| `paper-edge` | sunlit: `{pal-cream-edge}` / workshop: `{pal-cream-edge}` | The cut edge, grain and stitch line of a paper card. Decoration only, never text. |

## Type

Families:

- `display-a`: "Cormorant Garamond", Garamond, "Times New Roman", serif
- `display-b`: "Alfa Slab One", Rockwell, "Arial Black", serif
- `body`: Jost, "Century Gothic", system-ui, sans-serif
- `sub`: "Tenor Sans", "Gill Sans", system-ui, sans-serif
- `body-alt`: "Albert Sans", system-ui, sans-serif

### Sunlit Atelier display (family `display-a`)

| Style | Size / line | Weight | Spacing | Usage |
| --- | --- | --- | --- | --- |
| `sa-display` | 96px / 92px | 400 | -1px | One per page: the home headline. Sentence case, never uppercase. |
| `sa-h1` | 60px / 62px | 400 | -1px | Page titles. |
| `sa-h2` | 40px / 44px | 400 |  | Section and collection names, and the wordmark at 30px. |
| `sa-quote` | 30px / 38px | 400 |  | Captions under a garment and short pull lines. |

### Bolt & Tag display (family `display-b`)

| Style | Size / line | Weight | Spacing | Usage |
| --- | --- | --- | --- | --- |
| `bt-display` | 92px / 92px | 400 | 0 | The home headline, uppercase in CSS, on ground only. |
| `bt-h1` | 64px / 64px | 400 |  | Page titles, uppercase. |
| `bt-h2` | 40px / 42px | 400 |  | Row labels, tag titles and the wordmark at 36px, uppercase. |
| `bt-h3` | 26px / 30px | 400 | 1px | Card titles and button labels, uppercase. |

### Body text (Jost) (family `body`)

| Style | Size / line | Weight | Spacing | Usage |
| --- | --- | --- | --- | --- |
| `body-lead` | 21px / 32px | 300 |  | The one paragraph under a headline, under 40ch wide. Both looks. |
| `body-md` | 17px / 28px | 400 |  | Body copy, 56ch at most. Both looks. |
| `body-sm` | 14px / 22px | 400 |  | Addresses, captions and form labels. Both looks. |
| `body-figure` | 28px / 30px | 500 |  | Phone numbers and prices on a block. |

### Subheads and small text (Tenor Sans) (family `sub`)

| Style | Size / line | Weight | Spacing | Usage |
| --- | --- | --- | --- | --- |
| `sub-lg` | 24px / 32px | 400 | 0.2px | Subheadings under a display heading, and card titles on paper. |
| `sub-md` | 17px / 24px | 400 | 0.3px | Less prominent lines: product details, field hints, list titles. |
| `sub-caps` | 12px / 16px | 400 | 2px | Navigation, button labels, tag details and the strip at the top. Set uppercase in CSS, never in running text. |

### Body try-out (Albert Sans) (family `body-alt`)

| Style | Size / line | Weight | Spacing | Usage |
| --- | --- | --- | --- | --- |
| `alt-md` | 17px / 28px | 400 |  | Same size as body-md. To try Albert Sans, point the body family at body-alt; nothing else changes. |
| `alt-sm` | 14px / 22px | 400 |  | Same size as body-sm. |

## Spacing

| Token | Value | Usage |
| --- | --- | --- |
| `sa-space-1` | `8px` | Sunlit: gap between a label and its field. |
| `sa-space-2` | `16px` | Sunlit: gap between paragraphs and inside a button row. |
| `sa-space-3` | `24px` | Sunlit: gap between nav items and between a heading and its text. |
| `sa-space-4` | `40px` | Sunlit: column gutter and the gap between stacked blocks. |
| `sa-space-5` | `64px` | Sunlit: page side margin and gap between a headline and the section below. |
| `sa-space-6` | `96px` | Sunlit: space above and below a section. |
| `sa-space-7` | `160px` | Sunlit: the empty space above a home headline on wide screens. |
| `bt-space-1` | `4px` | Bolt & Tag: gap between a tag title and its details. |
| `bt-space-2` | `8px` | Bolt & Tag: gap between chips and inside a key button. |
| `bt-space-3` | `12px` | Bolt & Tag: padding inside a row cell. |
| `bt-space-4` | `16px` | Bolt & Tag: card padding and gap between tags. |
| `bt-space-5` | `24px` | Bolt & Tag: page side margin and section padding. |
| `bt-space-6` | `32px` | Bolt & Tag: gap between bands. |

## Radius

| Token | Value | Usage |
| --- | --- | --- |
| `sa-radius-square` | `0` | Sunlit: every box, button, field and image. Nothing is rounded. |
| `sa-radius-sun` | `50%` | Sunlit: the sun disc, the only round shape. |
| `bt-radius-key` | `4px` | Bolt & Tag: buttons, chips and inputs. |
| `bt-radius-paper` | `3px` | Bolt & Tag: corners of a paper card. Nearly square, like cut card stock. |
| `bt-radius-tag` | `10px` | Bolt & Tag: bottom corners of hang tags with a notch. |
| `bt-notch` | `14px` | Bolt & Tag: size of the cut top-left corner on a hang tag, drawn with clip-path. |

## Shadow

Sunlit Atelier uses no shadows. Bolt & Tag uses hard offset shadows with no blur, in maroon or clay, so a cream paper card looks stacked on the dark blue.

| Token | Value | Usage |
| --- | --- | --- |
| `bt-shadow-card` | `6px 6px 0 #9d0910` | Bolt & Tag: a paper card on dark blue, the default. Maroon, 1.6:1 on navy, so keep the card itself large. |
| `bt-shadow-card-clay` | `6px 6px 0 #ae847e` | Bolt & Tag: the clay alternative for small paper cards and tags, and for a card that sits on a maroon block. |
| `bt-shadow-raised` | `12px 12px 0 #9d0910` | Bolt & Tag: the one key section per page, such as the hero card. |
| `bt-shadow-key` | `4px 4px 0 #ae847e` | Bolt & Tag: buttons and chips at rest. Press by moving the button 3px and switching to bt-shadow-key-down. |
| `bt-shadow-key-down` | `1px 1px 0 #ae847e` | Bolt & Tag: a button while pressed. |
