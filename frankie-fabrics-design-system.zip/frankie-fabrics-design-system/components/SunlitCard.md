A product card for Sunlit Atelier: a tall flat photo ground, a hairline, the cut in Cormorant Garamond and the colour in Tenor Sans, and a text link. Use four to a row in a collection.

The consumer provides:

- A full-length garment photograph with a transparent or flat background.
- The cut ("London style" or "Turkey style") and a short description of colour and fastening.
- A link target for "Enquire". Do not show a price until the client supplies one.

Do:

- Alternate the photo ground between `highlight`, `pal-sky-pale` and `ground-deep` so a row never reads as one block.
- Let the hem touch the bottom of the photo ground.

Don't:

- Add borders around the card, shadows or a price badge.
