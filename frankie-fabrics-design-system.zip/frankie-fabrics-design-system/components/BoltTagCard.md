The Bolt & Tag product card: cream paper with a punched hole, a stitched inner border, the style name, a reference code, a garment drawing, the colour name and an "Enquire" key, with a hard offset shadow. Use four to a row, alternating the maroon and clay shadow.

The consumer provides:

- The cut ("London style" or "Turkey style") and a reference code such as "Ref LN-04".
- A front-on garment image on a transparent background.
- The colour name and a link target for "Enquire". Do not show a price until the client supplies one.

Do:

- Use `on-paper` tokens for text on the card, and `on-highlight` on a clay card.
- Draw jacket lines in a colour that contrasts with the jacket fill.

Don't:

- Mix shadow colours on one card.
- Add shapes beyond the hole and the stitch line.
