The Bolt & Tag business card, front and back, drawn as cream paper cards with a grain, a dashed stitch line and a hard offset shadow on dark blue. There is no font picker: the cards use Alfa Slab One for the wordmark and name, Tenor Sans for small caps lines, and Jost for addresses.

The consumer provides the name and title, the two office addresses with phone numbers, the email, and the dealers line. Replace the jacket drawings and reference codes with real products when they exist.

Do:

- Keep the pinked edge to the top strip and the tags to the cut corner and the hole.
- Label each block with its own `on-` token.
- Keep type at 2.7% of the card width or larger so it prints at 7pt.
- Use the maroon shadow on the front and the clay shadow on the back.

Don't:

- Set `ink` text on `highlight` or `support`.
- Use a blurred shadow.
