The Sunlit Atelier business card, front and back, on a deeper cream. There is no font picker: Cormorant Garamond for the wordmark and name, Jost for addresses, and Tenor Sans for the small caps lines.

The consumer provides the name and title, the two office addresses with phone numbers, the email, and the dealers line. Replace the jacket drawing with a garment photograph when one exists.

Do:

- Keep one sun disc and one `highlight` field on the front.
- Keep type at 2.7% of the card width or larger so it prints at 7pt.

Don't:

- Add a second colour field, a shadow or a rounded corner.
