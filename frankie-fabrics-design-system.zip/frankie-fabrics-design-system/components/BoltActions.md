The Bolt & Tag controls: the maroon key, the paper key, the clay key, a pressed and a focused state, style chips that toggle, and an order form on a paper card with a consent checkbox. Use these for every action on a `workshop` page.

The consumer provides button labels in sentence case (the style sets them uppercase), the chip options, the form field names and the consent wording.

Do:

- Use the maroon key for the main action, one per view. Other keys are paper or clay.
- Mark the chosen chip with `aria-pressed="true"`. The pressed chip becomes a small paper card.
- Put the form on a paper card. Keep inputs on `paper` with a 2px `on-paper` border.
- Show focus with the 3px `focus` outline and a 3px offset.

Don't:

- Set a clay key on a clay block.
- Round a key past `bt-radius-key`.
- Use blurred shadows.
