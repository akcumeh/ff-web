The Bolt & Tag home page on dark blue: a maroon top strip with a pinked edge, a header with a call key, a signage headline beside two paper tags, four paper cards for who the shop sells to, and a dark footer. Use it as the layout for the first screen of any `workshop` page.

The consumer provides:

- One headline in `bt-display`, set uppercase.
- One or two sentences for `body-lead`.
- Two products for the tags with a style name, a reference code and a garment image or the drawing placeholder.
- Four paper cards, each with a label band and one short line.
- The office addresses and phone numbers.

Do:

- Give the hero tag `bt-shadow-raised` and the other cards the default or clay shadow.
- Label every block with its own `on-` token.
- Keep the pinked edge to the top strip.
- Let tags overlap by a small amount and tilt them by 4 degrees at most.

Don't:

- Set `ink` text on `highlight` or `support`.
- Put a focusable control on a `highlight` block.
- Use soft shadows or pill shapes.
