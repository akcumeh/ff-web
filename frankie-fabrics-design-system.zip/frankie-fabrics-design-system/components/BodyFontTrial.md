# Body font try-out

Jost against Albert Sans, each in both looks, with the same sizes. Jost is the body font on the whole site. Albert Sans is the one alternative to try: it is a little wider and has a plainer, more upright shape, so long paragraphs and phone numbers read more steadily.

To try it, point the `body` family at `body-alt` in tokens.json. Nothing else changes, because every body style takes its font from that one family. Tenor Sans stays on subheads and small labels in both cases.
