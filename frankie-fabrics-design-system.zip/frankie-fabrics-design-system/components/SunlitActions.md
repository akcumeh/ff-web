The Sunlit Atelier controls: a solid maroon primary button, an outlined secondary button, an underlined text link and an order form with underline fields. Use these for every action on a `sunlit` page.

The consumer provides button labels in sentence case (the style sets them uppercase), and the form field names, which are plain words such as "Phone number" and "Style".

Do:

- Use one primary button per view.
- Keep labels to a verb phrase of four words or fewer.
- Show focus with the 3px `focus` outline and a 2px offset.

Don't:

- Round the corners, add a shadow or fill a field with a box.
- Use `accent` for anything except the primary button and one word of emphasis.
