The Sunlit Atelier home page: a header, a headline beside one deeper sky field, four collections in a row and a footer with both office addresses. Use it as the layout for the first screen of any `sunlit` page.

The consumer provides:

- One headline of five words or fewer, set in `sa-display`.
- One sentence for `body-lead`.
- One garment image for the `highlight` field. The previews draw a jacket as a placeholder.
- Four collection names (Church, Office, Events and Uniforms) with one line each.
- The two office addresses, phone numbers and the email.

Do:

- Keep one `sa-display` headline, one deeper sky field and one sun disc.
- Let the garment touch the bottom edge of the field.
- Keep the header and the collections separated by hairlines only.

Don't:

- Add a second colour field, a shadow or a rounded corner.
- Put a small label above the headline.
