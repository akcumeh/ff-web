# Frankie Fabrics design system

Read this file first. It lists every file and what it holds.

- `README.md`: brand, voice, content rules, fonts, how to use the tokens, accessibility.
- `look-1-sunlit-atelier.md`: the light look (cream, navy, deeper sky, Cormorant Garamond with Jost).
- `look-2-bolt-and-tag.md`: the dark look (dark blue ground, cream paper cards, maroon and clay offset shadows, Alfa Slab One with Jost).
- `tokens.md`: all colour, type, spacing, radius and shadow tokens in tables.
- `components/`: one file per component (home page, product card, actions, business card, body font try-out), each saying what to provide, what to do and what to avoid.

Theme ids are `sunlit` (light) and `workshop` (dark). The live system with visual previews is the Design System artifact in Claude.
