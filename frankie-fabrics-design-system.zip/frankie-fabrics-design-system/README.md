Frankie Fabrics sells ladies' suits. This system holds two looks for that one business. They are the light mode and the dark mode of the same site, so build every page in one look at a time and never mix them on a screen.

| Look | Theme id | Token prefix | Mode | Default for | Feel |
| --- | --- | --- | --- | --- | --- |
| Sunlit Atelier | `sunlit` | `sa-` | Light | About page, and the home page | Minimalist, elite, high fashion, sunny |
| Bolt & Tag | `workshop` | `bt-` | Dark | Gallery page, and the changing room | Cream paper labels with hard maroon and clay shadows on dark blue |

The full rules for each look are in the two sections that follow this page.

## Fonts

- Jost is the body font in both looks and on every page. The `body` family holds it.
- Cormorant Garamond sets Sunlit Atelier headings (`display-a`). Alfa Slab One sets Bolt & Tag headings (`display-b`).
- Tenor Sans (`sub`) sets subheadings and the less prominent small text: product details, field labels, navigation and tag lines.
- Albert Sans (`body-alt`) is the one alternative body font to try in place of Jost. Point the `body` family at it to test; no other token changes. The "Body font try-out" card shows the two side by side.

## Using the tokens

- Set `data-theme="sunlit"` or `data-theme="workshop"` on the root element of the page.
- Colour components with the semantic tokens (`ground`, `ground-deep`, `surface`, `ink`, `ink-soft`, `line`, `accent`, `on-accent`, `accent-text`, `highlight`, `on-highlight`, `support`, `on-support`, `focus`). They change value with the theme, so one component follows either look.
- The paper card has its own set: `paper`, `on-paper`, `on-paper-soft`, `accent-on-paper` and `paper-edge`. Text on a paper card always uses the `on-paper` tokens, not `ink`, because `ink` is cream in the dark look.
- Use the `pal-` tokens only for decoration that must keep one colour in both themes. The two supplied colours are called `pal-maroon` (the red on the card) and `pal-clay` (the dusty rose from palette 2). The derived ones (`pal-cream-light`, `pal-cream-deep`, `pal-cream-edge`, `pal-sky-pale`, `pal-sky-deep`, `pal-sun`, `pal-violet-ink`, `pal-navy-deep`, `pal-navy-raised`, `pal-clay-light`, `pal-slate-light`, `pal-ink-mid`) exist so that every text pair reaches 4.5:1 and the light look can run on a slightly deeper sky blue.
- Take spacing, radius and shadow tokens with the prefix of the chosen look. `sa-` goes with `sunlit` and `bt-` goes with `workshop`. Type styles for body text (`body-*`) and subheads (`sub-*`) are shared by both looks.
- Load the fonts from Google Fonts: Cormorant Garamond (400, 500, 400 italic), Alfa Slab One (400), Jost (300, 400, 500), Tenor Sans (400) and, for the try-out, Albert Sans (400, 500). The lettering on the original business card is not part of this system.

## Content fundamentals

The facts below never change between looks.

- The business is Frankie Fabrics Ent., general merchants, dealers in ladies' London and Turkey suits. It has traded since 2012. The CEO is Sir Frank Umeh.
- It sells retail and wholesale. Buyers are churchgoers, office workers, event organisers, and companies or groups ordering in bulk as uniforms.
- Head office: 43 Martins Street (Brasas Plaza), Lagos Island. Tel 07081156800.
- Branch office: No 35/37 Martins Street (Faith Plaza), Lagos Island. Tel 07069743721, 08098269558.
- Email: frankiefabrics@yahoo.com.

Voice and wording:

- Write plain business English. One idea per sentence. Say what is sold, where, and how to order.
- Write "London style" and "Turkey style" for the two cuts, with a capital letter on the place name. Write "ladies' suits" with the apostrophe after the s.
- Write the name as "Frankie Fabrics". Use "Frankie Fabrics Ent." only in legal or address lines.
- Never use exclamation marks, emoji, slogans or invented figures. The client has not supplied prices, sizes or minimum orders, so the call to action on a product is "Enquire".
- Write phone numbers without spaces, as on the card.
- Buttons name what the customer does: "Visit the showroom", "Order in bulk", "Call the branch", "Send request", "Enquire".

Copy that fits:

> Ladies' London and Turkey suits. Wholesale and retail from Martins Street, Lagos Island. Since 2012.

> Ordering for a team? Send a list of styles and sizes, or give us the date and the head count.

Copy that does not fit: anything that praises the brand ("the finest suits in Lagos"), anything with a made-up number, and anything that reads as a slogan.

## Accessibility

- Every text pair named in a token note holds 4.5:1 or better in its theme. Check a new pair before using it.
- The focus ring is a 3px solid outline in `focus` with an offset, in both looks.
- In Bolt & Tag, `ink` text fails on `highlight` and `support`. Use `on-highlight` and `on-support` there.
- The maroon shadow is only 1.6:1 against dark blue. It is decoration, so it carries no meaning on its own, and every card it sits under is also separated from the ground by its cream fill.

## What is not in this system

- No logo file was supplied. Set the name in type as each look describes, and do not draw a mark.
- No photographs were supplied. The jacket drawings in the previews are placeholders for product photography.
- No icon set was supplied. Each look says what to use if a glyph is unavoidable.
