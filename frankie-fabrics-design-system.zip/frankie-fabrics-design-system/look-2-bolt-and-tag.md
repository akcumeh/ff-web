# Bolt & Tag

Theme `workshop`, prefix `bt-`. This is the dark mode, and it is the default for the Gallery page and the changing room. The page is dark blue. Everything that carries information sits on a cream paper card: stiff label stock, the kind tied to new jeans, harder and flatter than embossed card. Each card throws a hard offset shadow in maroon or clay, with no blur, so the cards look stacked on the blue.

## Colour

- Set the page on `ground` (navy), the footer on `ground-deep`, and quiet panels or inputs on `surface`. Text on the blue is `ink` (cream) and captions are `ink-soft`.
- Information lives on `paper`. Text on it is `on-paper`, captions are `on-paper-soft`, and words in the brand colour are `accent-on-paper` (maroon).
- Colour arrives as solid blocks inside or beside the paper: `accent` (maroon), `highlight` (clay), `support` (grey-teal) and `on-paper` (navy). Label each block with its own pair: `on-accent`, `on-highlight`, `on-support`, or `paper` on a navy block.
- Never set `ink` text on `highlight` or `support`. Those pairs reach only 2.9:1 and 2.8:1.
- Maroon text on navy fails, so accent words on the blue use `accent-text` (the light clay).
- Do not place a focusable control directly on `highlight`. The focus ring reaches only 2:1 there. Put controls on `ground`, `surface`, `paper` or `accent`.
- Gradients, glows and blurred shadows are not used.

## Type

- Signage is Alfa Slab One in uppercase. It has one weight, so never bold it: `bt-display` for the home headline, then `bt-h1`, `bt-h2` and `bt-h3`.
- Reading text is Jost in sentence case: `body-md`, `body-sm` and `body-lead`. It is the same Jost as the light look.
- Subheadings and small text are Tenor Sans: `sub-lg` and `sub-md` for lines under a title, `sub-caps` for product codes, tag details, form labels and the top strip, set uppercase with wide tracking.
- Phone numbers and prices use `body-figure` (Jost 500), in `accent-on-paper` on paper.
- Align text left. Headlines may run the full width of the page.

## Construction

- The paper card is `paper` with a 1px `paper-edge` border, `bt-radius-paper` corners, a faint paper grain, and a 2px dashed stitch line in `paper-edge` inset 7px from the edge. A hang tag adds a punched hole in the `ground` colour near the top edge.
- Every paper card has a hard shadow with no blur: `bt-shadow-card` (maroon) by default, `bt-shadow-card-clay` for alternate cards in a row, and `bt-shadow-raised` (12px) for the one key section on a page, such as the hero card. Never use two shadow colours on one card.
- A tag with a cut corner uses `bt-notch` and a clip-path, which cuts off box-shadow, so put the shadow on a wrapper with `filter: drop-shadow` in the same colour.
- A button is a key: `bt-radius-key` corners and `bt-shadow-key` (clay) at rest. On press it moves 3px down and right and switches to `bt-shadow-key-down`. The primary key is maroon with cream text. The secondary key is a paper key with a maroon shadow. Labels are uppercase Alfa Slab One at 18px.
- Stitching on the blue is a 2px dashed `line`. Use it for page dividers. Inside paper, use `paper-edge`.
- The pinked (zigzag) edge, 6px deep, appears once, under the top strip.
- Spacing comes from `bt-space-*`. A tag may tilt by up to 4 degrees. Nothing else tilts.

## Imagery

Cut out the garment and set it front-on and centred on a paper card or a solid `highlight` or `support` block, always with a title that gives the style name and a reference code (for example "Ref LN-04"). The line drawings in the previews stand in until photography exists.

## Interaction

- Key buttons press down 3px. Chips toggle with `aria-pressed`: pressed turns into a small paper card with a key shadow.
- Focus is a 3px `focus` outline with a 3px offset (`focus` is sky blue, which reads on navy, paper and maroon).
- Form labels are `sub-caps` in `on-paper-soft`. Inputs sit on the paper card, are 46px tall with a 2px `on-paper` border and `paper` fill. The consent checkbox is a 26px square with a 2px `on-paper` border and a maroon square when checked.

## Iconography

No icon set was supplied. Navigation and buttons use words only. If a glyph is required, draw it as a 24px outline with a 2.5px stroke in `ink` (or `on-paper` on paper) and square caps. Lucide at that stroke weight is the closest library and counts as a substitute to flag. Emoji are not used.

## Logo

No logo file was supplied. Set FRANKIE FABRICS in Alfa Slab One at 34px, uppercase, in `ink` with 1px letter spacing. Do not add a symbol.

## Avoid

Soft blurred shadows, pill buttons, cards with a coloured left edge, labels above headlines, grid or dot backgrounds and gradients. Keep tags to the cut corner and the hole. Do not mix light-look elements (hairline-only layouts, the sun disc) into this look.

## Business card

The card is 3.5 by 2 inches (7:4). Keep type at 7pt or larger, which is 2.7% of the card width. Both faces are cream paper with a grain, a dashed stitch line and a hard offset shadow, shown on dark blue. The front has the pinked maroon strip with "Wholesale and retail" and "Since 2012", the wordmark in Alfa Slab One on the paper, a stitched line, "General merchants" in Tenor Sans, the dealers line in Jost, and two overlapping hang tags (clay for London, navy for Turkey) with a maroon shadow. The back is a maroon column with the name, beside a colour-blocked table of the two offices on the paper and a navy strip for the email; its shadow is clay. Tags tilt by 4 degrees at most. The cards are shown without a font picker.
