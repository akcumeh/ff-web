# Sunlit Atelier

Theme `sunlit`, prefix `sa-`. This is the light mode, and it is the default for the About page and the home page. A cream page, navy ink and a single field of a slightly deeper sky blue (`pal-sky-deep`, taken down from the supplied sky so the field holds its own against the cream). The look earns its elegance by leaving space empty, so every page carries more unused cream than content.

## Colour

- Set the page on `ground`. Set text in `ink` and captions in `ink-soft`. The footer sits on `ground-deep`.
- Use `highlight` (sky) as one flat field per view, behind a garment. Never place two sky fields side by side.
- Use `accent` (maroon) for the primary button and for one word of emphasis. A red section background is never used.
- Use `pal-sun` for one disc per view, shaped with `sa-radius-sun`, resting on a `highlight` field. It is decoration and never carries text.
- Use `support` (periwinkle) for a second garment colour or a small tile. Text on it is `on-support` at 17px or larger.
- Hover fills use `pal-sky-pale`. Links in running text use `pal-violet-ink`.
- Gradients, glows and transparency are not used. Every colour is flat.

## Type

- The home headline is `sa-display`, once per page, in sentence case. Section and collection names are `sa-h2`. Captions under a garment are `sa-quote`, which is the italic.
- Body copy is Jost: `body-md`. The one paragraph under a headline is `body-lead`. Addresses and form labels are `body-sm`.
- Subheadings and less prominent lines are Tenor Sans: `sub-lg` under a display heading, `sub-md` for product details. `sub-caps` is uppercase with wide tracking and appears only in navigation, button labels and footer labels. It never sits above a heading as a label.
- Align text left. Keep lines to 56 characters or fewer.

## Space and shape

- Page side margins are `sa-space-5`. Sections are separated by `sa-space-6`. The gap between columns is `sa-space-4`.
- Every box, button, field and photo is square (`sa-radius-square`). The sun disc is the only round shape.
- Separate content with 1px hairlines in `line`. Do not use shadows, filled cards or bordered boxes. The paper card of Bolt & Tag is not used here.
- Compose asymmetrically: a narrow text column beside one tall image field that runs to the page edge. Collections sit in a row of four, divided by vertical hairlines.

## Imagery

Photograph one garment per frame, full length, in daylight, on a flat `highlight`, `pal-sky-pale` or `ground-deep` backdrop. Crop at the hem or let the hem touch the frame edge. Skip collages, filters and overlaid text. The line drawings in the previews stand in until photography exists.

## Interaction

- The primary button is `accent` with `on-accent` text, 56px tall, 32px side padding. On hover it turns `ink` with `ground` text.
- The secondary button is a 1px `ink` outline on a transparent fill.
- Hover changes colour and nothing else. Nothing moves.
- Form fields have a 1px bottom border in `line` and no box.
- Focus is a 3px `focus` outline with a 2px offset.

## Iconography

No icon set was supplied, so headings carry none. If a glyph is required (phone, mail, map pin), draw it as a 24px outline with a 1.25px stroke in `ink` and square caps. Lucide at that stroke weight is the closest library and counts as a substitute to flag. Emoji are not used.

## Logo

No logo file was supplied. Set "Frankie Fabrics" in Cormorant Garamond 400 at 30px in `ink`, sentence case, as the preview header does. Do not add a symbol.

## Avoid

Small uppercase labels above headlines, grid or dot backgrounds, gradients, glowing pills, rounded corners, shadows, and headlines built to sound catchy. Say plainly what the business sells.

## Business card

The card is 3.5 by 2 inches (7:4). Keep type at 7pt or larger, which is 2.7% of the card width. The front is the wordmark in `sa-h2`-style Cormorant Garamond on `ground`, a hairline, "General merchants" in tracked uppercase Tenor Sans and the dealers line in Jost, beside one `highlight` field holding the sun disc and a garment. The back holds the name in Cormorant Garamond, "C.E.O." in Tenor Sans in `accent-text`, a hairline, the two offices in two columns and the email. A 4% strip of `accent` over `highlight` runs down the right edge. The cards are shown without a font picker: Cormorant Garamond and Jost, with Tenor Sans for the small caps lines. Nothing else is added.
