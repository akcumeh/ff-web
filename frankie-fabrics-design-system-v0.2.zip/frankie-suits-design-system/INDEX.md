# Frankie Suits design system

Read this file first. It lists every file and what it holds.

- `README.md`: brand, the two modes, fonts, how to use the tokens, accessibility.
- `foundations.md`: the visual rules (layout, colour, type, photographs, what to avoid).
- `business-cards.md`: the one-sided and two-sided business card rules.
- `tokens.md`: all colour, type, spacing and radius tokens in tables, with per-mode values.
- `components/`: one file per component (home page, product card, actions, one-sided card, two-sided card), each saying what to provide, what to do and what to avoid.
- `photos/`: the model photographs and a README on how to crop and use them.

The system is one look in two modes. Theme ids are `light` and `dark`. The fonts are Cormorant Garamond, Albert Sans and Tenor Sans. There are no circles, shadows or decorative shapes.
