# Business cards

The card is 3.5 by 2 inches (7:4). Set type in container units so one layout scales from a screen preview to print. 2.7% of the card width prints at 7pt, which is the smallest size used for addresses. The "Turn over" note is the one exception at 2.4%.

Every card carries photographs and nothing decorative: no circles, no shapes added for effect. Every card has a photographic side. A line-up or a two-sided front takes two or three of the supplied photographs and a panel takes one, each cropped to the figure with the head near the top edge. The card ground is `ground` in the current mode, the border is 1px `line`, and the stage behind it is `ground-deep`.

## One-sided cards

A one-sided card carries everything on the front. Use it when the owners want one glance to do the whole job, as the original card does.

- **Line-up.** Three photographs and one `highlight` cell with the wordmark run edge to edge across the top 42% of the card, with a half-percent gap between them. Below sit one line ("General merchants. Dealers in ladies' London and Turkey suits."), a hairline and the two offices in two columns. A maroon `band` along the bottom holds the CEO's name in Cormorant Garamond italic on the left and the email on the right.
- **Panel.** One full-height photograph fills the right quarter. The left holds the wordmark on one line, the same line of text, a hairline, the two offices and the maroon band with the name and email. It is denser than the line-up, so check the branch phone line before printing.

## Two-sided cards

A two-sided card keeps the front quiet and the back practical.

- **Front.** Two full-height photographs fill the left 60%. The right is a `highlight` field holding the wordmark in two lines and the one line of text. A note reading "Turn over" sits at the bottom right in Tenor Sans at 2.4% of the card width, in `on-highlight`. Never leave it off: without it people miss the back.
- **Back.** The name in Cormorant Garamond at 8.6% of the card width, "C.E.O." in tracked Tenor Sans capitals in `accent-text`, a hairline, the two offices in two columns, and a maroon `band` holding the email.

## Do and do not

- Do keep one `highlight` field per card side.
- Do use different photographs on the light and dark versions of the same design, so a pair of cards shows more of the range.
- Do not add a shadow, a circle, a rounded corner, a dotted line or a second colour field.
- Do not place a photograph with half-visible lettering on a card. Crop it first.
- Do not print the dark card on thin stock without a test: a navy ground shows every scuff.
