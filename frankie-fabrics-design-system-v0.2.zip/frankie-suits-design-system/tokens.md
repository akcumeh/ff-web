# Tokens

Every token with its value and when to use it. Values written as `{name}` point to another token. Per-mode values are shown as `light / dark`.

## Colour

| Token | Value | Usage |
| --- | --- | --- |
| `pal-maroon` | `#9d0910` | Supplied card red, renamed maroon. Fill of the primary button in light mode and of the bottom band on cards in both modes. Text on it is cream (7.5:1). As text it reads on cream (7.5:1), never on navy (1.6:1). |
| `pal-cream` | `#fdf0d5` | Supplied card cream. Page ground in light mode, text colour in dark mode, and the primary button in dark mode. |
| `pal-navy` | `#003049` | Supplied card navy. Ink in light mode and the page ground in dark mode. |
| `pal-periwinkle` | `#6f69b1` | Supplied palette violet. Second colour field in both modes. It is 4.3:1 on cream, so never small text; use pal-violet-ink for text. |
| `pal-sky` | `#84d2f6` | Supplied palette sky blue. Links, small accent words and the focus ring in dark mode (8.3:1 on navy). Light mode uses the deeper pal-sky-deep for its field. |
| `pal-cream-light` | `#fff9ec` | Derived: the lightest cream. Raised surfaces in light mode and text on periwinkle. |
| `pal-cream-deep` | `#f4e2b8` | Derived: a deeper cream for the footer band and quiet fields in light mode. |
| `pal-sky-pale` | `#d6eefb` | Derived: sky tint for hover fills in light mode. |
| `pal-sky-deep` | `#5fb9e8` | Derived: the supplied sky taken down a step. The large flat field in light mode. Navy text on it is 6.3:1. Maroon text is not allowed on it (3.9:1). |
| `pal-violet-ink` | `#55509a` | Derived: periwinkle darkened until it reads as text (6.2:1 on cream). Links and the focus ring in light mode. |
| `pal-ink-mid` | `#3f5d70` | Derived: mid navy for secondary text on cream in light mode (5.5:1 or better). |
| `pal-navy-deep` | `#00202f` | Derived: the deepest navy. Footer band and card backdrop in dark mode. |
| `pal-navy-raised` | `#0b4160` | Derived: lifted navy for panels, inputs and the photo field in dark mode. |
| `pal-mist` | `#b7cdda` | Derived: pale blue-grey for secondary text in dark mode (6.6:1 on raised navy, 8.4:1 on navy). |
| `pal-steel` | `#6a8ea4` | Derived: navy lightened toward sky for hairlines and form borders in dark mode (4.0:1 on navy, 3.1:1 on raised navy). A line, never text. |
| `ground` | `{pal-cream}` / `{pal-navy}` | Page background. Text on it: ink, ink-soft, accent-text, link. |
| `ground-deep` | `{pal-cream-deep}` / `{pal-navy-deep}` | Footer, backdrop behind business cards and quiet bands under ground. Text on it: ink, ink-soft, accent-text, link. |
| `surface` | `{pal-cream-light}` / `{pal-navy-raised}` | Raised areas: panels, inputs and product photo grounds. Text on it: ink, ink-soft, accent-text, link. |
| `ink` | `{pal-navy}` / `{pal-cream}` | Headlines and body copy on ground, ground-deep and surface (9.5:1 or better in both modes), and on highlight. |
| `ink-soft` | `{pal-ink-mid}` / `{pal-mist}` | Secondary copy and captions on ground, ground-deep and surface (5.4:1 or better in both modes). Not on highlight in light mode (3.2:1). |
| `line` | `{pal-navy}` / `{pal-steel}` | Hairlines and form borders, 1px. Meets 3:1 on ground and on surface in both modes (dark: 3.1:1 on surface). |
| `accent` | `{pal-maroon}` / `{pal-cream}` | Fill of the primary button: maroon in light mode, cream in dark mode (maroon on navy is only 1.6:1). Label it with on-accent. |
| `on-accent` | `{pal-cream}` / `{pal-navy}` | Text on accent (7.5:1 in light mode, 12.3:1 in dark mode). |
| `accent-hover` | `{pal-navy}` / `{pal-sky}` | Fill of the primary button on hover. Label it with on-accent-hover. |
| `on-accent-hover` | `{pal-cream}` / `{pal-navy}` | Text on accent-hover (12.3:1 in light mode, 8.3:1 in dark mode). |
| `accent-text` | `{pal-maroon}` / `{pal-sky}` | Accent coloured words on ground, ground-deep and surface: maroon in light mode (6.6:1 or better), sky in dark mode (6.5:1 or better). |
| `band` | `{pal-maroon}` / `{pal-maroon}` | The maroon band: the bottom strip of a business card and the footer rule on a page. Same in both modes. Text on it: on-band. |
| `on-band` | `{pal-cream}` / `{pal-cream}` | Text on band (7.5:1). |
| `highlight` | `{pal-sky-deep}` / `{pal-navy-raised}` | The one large colour field per view: deeper sky in light mode, raised navy in dark mode. It holds the wordmark on a card or a photograph on a page. Text on it: on-highlight. |
| `on-highlight` | `{pal-navy}` / `{pal-cream}` | Text on highlight (6.3:1 in light mode, 9.6:1 in dark mode). |
| `support` | `{pal-periwinkle}` / `{pal-periwinkle}` | Second colour field, a small tile. Same in both modes. Text on it: on-support. |
| `on-support` | `{pal-cream-light}` / `{pal-cream-light}` | Text on support (4.6:1). Use at 17px or larger. |
| `hover` | `{pal-sky-pale}` / `{pal-navy-raised}` | Fill of a secondary button or a row on hover. Text on it: ink (11.5:1 in light mode, 9.6:1 in dark mode). |
| `link` | `{pal-violet-ink}` / `{pal-sky}` | Links in running text on ground, ground-deep and surface: violet in light mode (5.4:1 or better), sky in dark mode (6.4:1 or better). |
| `focus` | `{pal-violet-ink}` / `{pal-sky}` | Focus ring, 3px solid with a 2px offset, so it sits on ground or surface. At least 3:1 on both in both modes. |

## Type

Font families:

- `display`: `"Cormorant Garamond", Garamond, "Times New Roman", serif`
- `body`: `"Albert Sans", system-ui, "Segoe UI", sans-serif`
- `sub`: `"Tenor Sans", "Gill Sans", system-ui, sans-serif`

### Display (Cormorant Garamond)

| Style | Size / line | Weight | Usage |
| --- | --- | --- | --- |
| `display` | 96px / 92px | 400, tracking -1px | One per page: the home headline. Sentence case, never uppercase. |
| `h1` | 60px / 62px | 400, tracking -1px | Page titles. |
| `h2` | 40px / 44px | 400 | Section and collection names, and the wordmark at 30px. |
| `quote` | 30px / 38px | 400 italic | Captions under a garment and short pull lines. |

### Body text (Albert Sans)

| Style | Size / line | Weight | Usage |
| --- | --- | --- | --- |
| `body-lead` | 21px / 32px | 300 | The one paragraph under a headline, under 40ch wide. |
| `body-md` | 17px / 28px | 400 | Body copy, 56ch at most. |
| `body-sm` | 14px / 22px | 400 | Addresses, captions and form labels. |
| `body-figure` | 28px / 30px | 500 | Phone numbers on a block. |

### Subheads and small text (Tenor Sans)

| Style | Size / line | Weight | Usage |
| --- | --- | --- | --- |
| `sub-lg` | 24px / 32px | 400, tracking 0.2px | Subheadings under a display heading. |
| `sub-md` | 17px / 24px | 400, tracking 0.3px | Less prominent lines: product details, field hints, list titles. |
| `sub-caps` | 12px / 16px | 400, tracking 2px | Navigation, button labels and footer labels. Set uppercase in CSS, never in running text. |

## Spacing

| Token | Value | Usage |
| --- | --- | --- |
| `space-1` | `8px` | Gap between a label and its field. |
| `space-2` | `16px` | Gap between paragraphs and inside a button row. |
| `space-3` | `24px` | Gap between nav items and between a heading and its text. |
| `space-4` | `40px` | Column gutter and the gap between stacked blocks. |
| `space-5` | `64px` | Page side margin and the gap between a headline and the section below. |
| `space-6` | `96px` | Space above and below a section. |
| `space-7` | `160px` | The empty space above a home headline on wide screens. |

## Radius

| Token | Value | Usage |
| --- | --- | --- |
| `radius-square` | `0` | Every box, button, field and photo. Nothing in the system is rounded. |

There is no shadow family. Nothing in this system casts a shadow.
