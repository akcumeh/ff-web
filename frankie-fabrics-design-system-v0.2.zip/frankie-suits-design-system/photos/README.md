Model photographs of current Frankie Suits designs, supplied by the owners. They are generated model images, cropped to the figure, with the lettering that appeared on the studio backdrop and the overlaid captions cut out. Each is a full-colour JPEG, so none of them takes an ink colour.

- `cream-coat.jpg`: long cream jacquard jacket over a matching dress. Light backdrop with a pink tint. Hero photograph on the home page and the first photo on the light cards.
- `purple-suit.jpg`: purple skirt suit with a lace-panelled jacket, a fascinator and a clutch. Warm cream room. Used on product cards and on both card modes.
- `lilac-jacket.jpg`: lilac herringbone jacket over a purple dress, on a white staircase. Used on product cards and on the panel card.

Crop each photograph with the head near the top of the frame. Do not put text over them. Replace them with real studio photography when it exists; keep the file names so the previews keep working.
