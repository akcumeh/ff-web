A product card: a 3:4 photograph on a `surface` ground, a hairline, the product name in `h2`, one detail line in `sub-md` and two text links, "Enquire" and "Try it on". Three cards sit in a row with a `space-4` gap, shown in light above and dark below.

The consumer provides the photograph, the product name and one detail line. The names in the preview are samples. The links go to the order enquiry and to the changing room with the product preselected.

Do:

- Crop the photograph with the head near the top and no lettering visible on the backdrop.
- Keep the links as underlined text. Hover turns them to `accent-text`.

Don't:

- Show a price, a size or a stock figure until the owners supply them.
- Frame a photograph with a border or a shadow.
