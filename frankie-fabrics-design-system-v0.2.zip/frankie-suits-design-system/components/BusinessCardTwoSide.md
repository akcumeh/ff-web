A two-sided business card, front and back, in light above and dark below. The front holds two full-height photographs, a `highlight` field with the wordmark, one line of text and a small "Turn over" note at the bottom right. The back holds the name, the title, the two offices and the maroon band with the email.

The consumer provides the photographs, the name and title, the offices and the email. Keep the "Turn over" note on every front.

Do:

- Set "Turn over" in Tenor Sans at 2.4% of the card width in `on-highlight`.
- Use different photographs on the light and dark pairs.

Don't:

- Put a photograph on the back.
- Drop the "Turn over" note. People miss the back without it.
