Two one-sided business cards, each shown in light and dark: the line-up (three photographs and a wordmark cell across the top, details below) and the panel (details on the left, one full-height photograph on the right). All the information sits on the front.

The consumer provides the name and title, the two offices with phone numbers, the email, the one line of text and the photographs. Use the supplied photographs from `assets/Photos`.

Do:

- Keep type at 2.7% of the card width or larger so it prints at 7pt.
- Keep one `highlight` cell per card and no circles.
- Crop each photograph so the head is near the top and no backdrop lettering shows.

Don't:

- Add a shadow, a dotted line, an angled corner or a second colour field.
- Put the card on a stage other than `ground-deep`.
