The home page at 1200px wide, light above and dark below. A 88px header with the wordmark and four navigation items, a two-column hero (headline, one paragraph and two actions beside a `highlight` field holding a photograph), a row of four collections divided by hairlines, and a footer on `ground-deep` with the two offices and the email.

The consumer provides the headline, the paragraph, the photograph and its caption, the four collection names with one line each, and the office details.

Do:

- Keep the headline to one `display` line of copy, in sentence case.
- Put the hem of the photograph on the bottom edge of the field.
- Keep one primary button per view.

Don't:

- Add a second `highlight` field, a shadow, a gradient or a rounded corner.
- Lay text over the photograph. The caption sits on the field beside it.
