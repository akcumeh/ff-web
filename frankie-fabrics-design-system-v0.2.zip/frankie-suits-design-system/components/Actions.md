Buttons, a text link and an order form, shown in light above and dark below. The primary button is `accent` on `on-accent` (maroon in light, cream in dark), the secondary button is a 1px `ink` outline, and the link uses `link`. Form fields are a bottom border in `line` with no box.

The consumer provides the button labels and the form fields. Labels name what the customer does.

Do:

- Keep one primary button per view.
- Set button labels in Tenor Sans through `sub-caps` and field text in Albert Sans.

Don't:

- Use maroon as a button fill on the dark page. It is 1.6:1 against navy; the dark primary button is cream.
- Add a shadow, a lift on hover or a rounded corner.
