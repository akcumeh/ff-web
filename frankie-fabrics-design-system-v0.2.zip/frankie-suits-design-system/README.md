Frankie Suits sells ladies' suits. This system holds one look in two modes. Light is a cream page with navy ink. Dark is the same look on a navy page with cream ink. Build each page in one mode at a time and never show both on one screen.

| Mode | Theme id | Page | Ink | Default for |
| --- | --- | --- | --- | --- |
| Light | `light` | cream | navy | Home, About, product pages, print |
| Dark | `dark` | navy | cream | Gallery, changing room, and any page the visitor switches to dark |

The visual rules are in the Foundations section. The business card rules are in the Business cards section.

## Fonts

- Cormorant Garamond (`display`) sets headlines, names and wordmarks.
- Albert Sans (`body`) sets all running text, addresses and form fields in both modes, on the site and on the cards.
- Tenor Sans (`sub`) sets navigation, button labels, footer labels and the less prominent lines under a heading. Use it sparingly. It is never a second body font.
- Load them from Google Fonts: Cormorant Garamond (400, 500, 400 italic), Albert Sans (300, 400, 500) and Tenor Sans (400). There are three typefaces and no alternatives to switch between. Jost is not used. The lettering on the original business card is not part of this system.

## Using the tokens

- Set `data-theme="light"` or `data-theme="dark"` on the root element of the page.
- Colour components with the semantic tokens: `ground`, `ground-deep`, `surface`, `ink`, `ink-soft`, `line`, `accent`, `on-accent`, `accent-hover`, `on-accent-hover`, `accent-text`, `link`, `band`, `on-band`, `highlight`, `on-highlight`, `support`, `on-support`, `hover`, `focus`. They change value with the mode, so one component follows either mode.
- The `pal-` tokens hold the five supplied colours (`pal-maroon`, `pal-cream`, `pal-navy`, `pal-periwinkle`, `pal-sky`) and the derived tints and shades that make every text pair reach 4.5:1. Use a `pal-` token only for decoration that must keep one colour in both modes.
- The primary button changes fill between modes: maroon with cream text in light, cream with navy text in dark. Maroon on navy is only 1.6:1, so maroon stays off the dark page except as a band that holds text.
- Take spacing from `space-1` to `space-7` and the one radius token. The system has no shadow tokens because nothing in it casts a shadow.
- Type styles are `display`, `h1`, `h2` and `quote` for headings, `body-*` for Albert Sans and `sub-*` for Tenor Sans.

## Content fundamentals

The facts below never change between modes.

- The business is Frankie Suits, general merchants, dealers in ladies' London and Turkey suits. It has traded since 2012. The CEO is Sir Frank Umeh. Older stationery and the email address still say Frankie Fabrics; print the address exactly as it is.
- It sells retail and wholesale. Buyers are churchgoers, office workers, event organisers, and companies or groups ordering in bulk as uniforms.
- Head office: 43 Martins Street (Brasas Plaza), Lagos Island. Tel 07081156800.
- Branch office: No 35/37 Martins Street (Faith Plaza), Lagos Island. Tel 07069743721, 08098269558.
- Email: frankiefabrics@yahoo.com.

Voice and wording:

- Write plain business English. One idea per sentence. Say what is sold, where, and how to order.
- Write "London style" and "Turkey style" for the two cuts, with a capital letter on the place name. Write "ladies' suits" with the apostrophe after the s.
- Write the name as "Frankie Suits". Do not use "Frankie Fabrics" in new copy.
- Never use exclamation marks, emoji, slogans or invented figures. The owners have not supplied prices, sizes or minimum orders, so the call to action on a product is "Enquire".
- Write phone numbers without spaces, as on the card.
- Buttons name what the customer does: "Visit the showroom", "Order in bulk", "Call the branch", "Send request", "Enquire", "Try it on".

Copy that fits:

> Ladies' London and Turkey suits. Wholesale and retail from Martins Street, Lagos Island. Since 2012.

> Ordering for a team? Send a list of styles and sizes, or give us the date and the head count.

Copy that does not fit: anything that praises the brand ("the finest suits in Lagos"), anything with a made-up number, and anything that reads as a slogan.

## Accessibility

- Every text pair named in a token note holds 4.5:1 or better in its mode. Check a new pair before using it.
- Form borders and hairlines hold 3:1 or better on `ground` and `surface` in both modes.
- The focus ring is a 3px solid outline in `focus` with a 2px offset, in both modes.
- In light mode `ink-soft` fails on `highlight` (3.2:1). Use `on-highlight` there.

## What is not in this system

- No logo file was supplied. Set the name in Cormorant Garamond and do not draw a mark.
- No icon set was supplied. Foundations says what to use if a glyph is unavoidable.
- The photographs in `assets/Photos` are model photographs the owners supplied. They are crops with the lettering on the backdrop removed. Replace them as new photography arrives.
