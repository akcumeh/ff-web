# Foundations

One look, two modes. It earns its elegance by leaving space empty, so every page carries more unused ground than content. Nothing is decorated: no shadows, no dotted or dashed lines, no angled or jagged shapes, no textures, no gradients.

## Colour

- Set the page on `ground`. Set text in `ink` and captions in `ink-soft`. The footer sits on `ground-deep`.
- Use `highlight` as one flat field per view, behind a photograph. In light it is the deeper sky blue. In dark it is the raised navy. Never place two highlight fields side by side.
- Use `accent` for the primary button and `accent-text` for one word of emphasis. A red section background is never used. The maroon `band` is allowed as the bottom strip of a card or a footer rule, because it holds text at 7.5:1.
- Use `support` (periwinkle) for a second colour field or a small tile. Text on it is `on-support` at 17px or larger.
- Links in running text use `link`. Hover fills on secondary controls use `hover`.
- Every colour is flat. There are no gradients, glows or transparency.

## Type

- The home headline is `display`, once per page, in sentence case. Section and collection names are `h2`. Captions under a photograph are `quote`, the italic.
- Body copy is Albert Sans: `body-md`. The one paragraph under a headline is `body-lead`. Addresses and form labels are `body-sm`.
- Tenor Sans carries only `sub-lg` under a display heading, `sub-md` for product details, and `sub-caps` for navigation, button labels and footer labels. `sub-caps` never sits above a heading as a label.
- Align text left. Keep lines to 56 characters or fewer.

## Space and shape

- Page side margins are `space-5`. Sections are separated by `space-6`. The gap between columns is `space-4`.
- Every box, button, field and photograph is square (`radius-square`). Nothing is round.
- Separate content with 1px hairlines in `line`. Do not use shadows, filled cards or bordered boxes.
- Compose asymmetrically: a narrow text column beside one tall `highlight` field that runs to the page edge. Collections sit in a row of four, divided by vertical hairlines.

## Imagery

- Show one garment per frame, full length or cropped at the hip, and always in a photograph on a light backdrop. Do not use collages, filters or text laid over a photograph.
- In a hero, mount the photograph on the `highlight` field with the hem touching the bottom edge.
- In a product card, crop the photograph to 3:4 with the top of the frame at the head, on a `surface` ground.
- Photographs that show lettering on the backdrop must be cropped so no half-visible lettering remains.

## Interaction

- The primary button is `accent` with `on-accent` text, 56px tall, 32px side padding. On hover it takes `accent-hover` with `on-accent-hover` text.
- The secondary button is a 1px `ink` outline on a transparent fill. On hover it fills with `hover`.
- Hover changes colour and nothing else. Nothing moves.
- Form fields have a 1px bottom border in `line` and no box.
- Focus is a 3px `focus` outline with a 2px offset.

## Iconography

No icon set was supplied, so headings carry none. If a glyph is required (phone, mail, map pin), draw it as a 24px outline with a 1.25px stroke in `ink` and square caps. Lucide at that stroke weight is the closest library and counts as a substitute to flag. Emoji are not used.

## Logo

No logo file was supplied. Set "Frankie Suits" in Cormorant Garamond 400 at 30px in `ink`, sentence case, as the preview header does. Do not add a symbol.

## Avoid

Small uppercase labels above headlines, grid or dot backgrounds, dotted or dashed rules, offset shadows, angled corners, gradients, glowing pills, rounded corners, circles, a fourth typeface, and headlines built to sound catchy. Say plainly what the business sells.
